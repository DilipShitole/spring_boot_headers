package com.crud2.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudOperation2Application {

	public static void main(String[] args) {
		SpringApplication.run(CrudOperation2Application.class, args);
	}

}
