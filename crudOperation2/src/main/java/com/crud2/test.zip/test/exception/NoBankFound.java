package com.crud2.test.exception;

public class NoBankFound extends RuntimeException {

	public NoBankFound(String message) {
		super(message);
		
	}

}
